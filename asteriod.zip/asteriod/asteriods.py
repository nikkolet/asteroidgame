"""
File: asteroids.py
Original Author: Br. Burton
Designed to be completed by Dhener Trinidad

This program implements the asteroids game.

My changes:
Background
sound for fire and hit
Down arrow will lessen the velocity of the ship
bounce added for asteroid and ship
limit the speed of the ship
End game will show congratulations and the time-lapse to finish the game.


############################################################################
About the bounce:
    The bounce will make the game more realistic in a way that the asteroid and ship have a chance to collide and bounce,
    sometimes they may not though they seems to collide (one might go under right?), 
    sometimes asteroids and ship may get stuck together just like what could possibly happen in real life,
    sometimes they will hit and bounce as intended. 
    Bounce might go to a totally opposite direction or just slide, or just move a little depending on the impact and angle

About Scoring and endgame:
    The ship will live until all the asteroids are gone.
    The score will depend on how long the player clears all the asteroids.
    The lower the score, the better.
    The game will end once all the asteroids were gone and the congratulatory message with the score will show at the center 
############################################################################

"""
import arcade
import math
import random
from abc import ABC, abstractmethod
import time


# These are Global constants to use throughout the game
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

BULLET_RADIUS = 30
BULLET_SPEED = 10
BULLET_LIFE = 60

SHIP_TURN_AMOUNT = 3
SHIP_THRUST_AMOUNT = 0.25
SHIP_RADIUS = 30

INITIAL_ROCK_COUNT = 5

BIG_ROCK_SPIN = 1
BIG_ROCK_SPEED = 1.5
BIG_ROCK_RADIUS = 15

MEDIUM_ROCK_SPIN = -2
MEDIUM_ROCK_RADIUS = 5

SMALL_ROCK_SPIN = 5
SMALL_ROCK_RADIUS = 2

class Point:
    """
    This will provide the location of the object
    """
    def __init__(self):
        self.x = 0.00 
        self.y = 0.00

class Velocity:
    """
    This helps in the movement of the object
    """
    def __init__(self):
        self.dx = 0
        self.dy = 0

class FlyingObject(ABC):
    """
    This will be the base class for flying objects
    """
    def __init__(self):
        self.center = Point()
        self.velocity = Velocity()
        self.alive = True #check if the object is still alive
        self.radius = 0.0
        self.angle = 0 #addtional attribute
    
    @abstractmethod
    def draw(self):
        pass

    def advance(self):
        """
        This will help in the movement of the object
        """
        self.center.x += self.velocity.dx #initial position += new possition
        self.center.y += self.velocity.dy #initial position += new possition
    
    def is_off_screen(self,width,height):
        """
        This will check if the object is off screen, sample, if an object goes off the right edge of the screen, 
        it should appear on the left edge.
        """        

        if self.center.x > width:
            self.center.x = 0
        elif self.center.x < 0:
            self.center.x = width
        elif self.center.y > height:
            self.center.y = 0
        elif self.center.y < 0:
            self.center.y = height

class Ship(FlyingObject):
    """
    This will have the ship functions and basic attributes
    """
    def __init__(self):
        super().__init__()
        self.angle = 0.00
        self.radius = SHIP_RADIUS
        self.center.x = SCREEN_WIDTH // 2
        self.center.y = SCREEN_HEIGHT //2

    def draw(self):
        try:    
            img = "D:/Program Files/d VS Code/asteriod/images/playerShip1_orange.png"
            texture = arcade.load_texture(img)
        #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        except FileNotFoundError:
            img = "images/playerShip1_orange.png"
            texture = arcade.load_texture(img)
        finally:
            width = texture.width
            height = texture.height
            alpha = 255

            x = self.center.x
            y = self.center.y
            angle = self.angle

            arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha) 
        
    def bounce_horizontal(self):
        """
        This will help in the movement of the ball, velocity helps in steering the ball bounce
        """
        self.velocity.dx *= -1 #inverse the movement of the ball
        

    def bounce_vertical(self):
        """
        This will help in the movement of the ball, velocity helps in steering the ball bounce
        """
        self.velocity.dy *= -1 #inverse the movement of the ball
        
class Bullet(FlyingObject):
    def __init__(self):
        super().__init__()
        self.radius = BULLET_RADIUS
        self.travel = 0

    def draw(self):
        
        try:
            img = "images/laserBlue01.png"
            texture = arcade.load_texture(img)
      #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        except FileNotFoundError:
            img = "D:/Program Files/d VS Code/asteriod/images/laserBlue01.png"
            texture = arcade.load_texture(img)

        finally:
            width = texture.width
            height = texture.height
            alpha = 255

            x = self.center.x  
            y = self.center.y
            angle = self.angle + 90 #+90 to straight up the laser

            arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha) 

    def fire(self, ship):
        """
        This will give the movement for our bullet and angel for its direction
        """
        self.center.x = ship.center.x
        self.center.y = ship.center.y
        self.angle += ship.angle
        self.velocity.dx = math.cos(math.radians(ship.angle - 270)) * BULLET_SPEED
        self.velocity.dy = math.sin(math.radians(ship.angle - 270)) * BULLET_SPEED
        self.velocity.dx += ship.velocity.dx
        self.velocity.dy += ship.velocity.dy  
       

class Asteroids(FlyingObject, ABC):
    def __init__(self):
        super().__init__()
        self.rotation = 0.00 #spin

    @abstractmethod
    def draw(self):
        pass

    def advance(self):
        """
        This will help in the movement of the object
        """
        self.angle += self.rotation #spin
        self.center.x += self.velocity.dx #initial position += new possition
        self.center.y += self.velocity.dy #initial position += new possition    
    
    @abstractmethod
    def hit(self):
        return

    def bounce_horizontal(self):
        """
        This will help in the movement of the ball, velocity helps in steering the ball bounce
        """
        self.velocity.dx *= -1 #inverse the movement of the ball
        

    def bounce_vertical(self):
        """
        This will help in the movement of the ball, velocity helps in steering the ball bounce
        """
        self.velocity.dy *= -1 #inverse the movement of the ball
        

class LargeAsteriods(Asteroids):
    def __init__(self):
        super().__init__()
        #position
        self.center.x = random.uniform(0,SCREEN_HEIGHT)
        self.center.y = random.uniform(SCREEN_HEIGHT,SCREEN_WIDTH)
        #speed
        self.velocity.dx = random.uniform(-BIG_ROCK_SPEED,BIG_ROCK_SPEED)
        self.velocity.dy = random.uniform(-BIG_ROCK_SPEED,BIG_ROCK_SPEED)
        self.rotation = BIG_ROCK_SPIN
        self.radius = BIG_ROCK_RADIUS
        
    def draw(self):

        try:
            img = "D:/Program Files/d VS Code/asteriod/images/meteorGrey_big1.png"
            texture = arcade.load_texture(img)
      #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        except FileNotFoundError:
            img = "images/meteorGrey_big1.png"
            texture = arcade.load_texture(img)

        finally:
            width = texture.width
            height = texture.height
            alpha = 255

            x = self.center.x
            y = self.center.y
            angle = self.angle

            arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha) 

    def hit(self):
        particles = [MediumAsteriods(self.center), MediumAsteriods(self.center), SmallAsteriods(self.center)]
        
        particles[0].velocity.dx = self.velocity.dx
        particles[0].velocity.dy = self.velocity.dy + 2

        particles[1].velocity.dx = self.velocity.dx
        particles[1].velocity.dy = self.velocity.dy + 2 * -1

        particles[2].velocity.dx = self.velocity.dx + 5
        particles[2].velocity.dy = self.velocity.dy

        return particles

class MediumAsteriods(Asteroids):
    def __init__(self,asteriod):
        super().__init__()
        self.rotation = MEDIUM_ROCK_SPIN
        self.radius = MEDIUM_ROCK_RADIUS
        self.center.x = asteriod.x
        self.center.y = asteriod.y

    def draw(self):
        try:
            img = "D:/Program Files/d VS Code/asteriod/images/meteorGrey_med1.png"
            texture = arcade.load_texture(img)
        #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        except FileNotFoundError:
            img = "images/meteorGrey_med1.png"
            texture = arcade.load_texture(img)
        finally:
            width = texture.width
            height = texture.height
            alpha = 255

            x = self.center.x
            y = self.center.y
            angle = self.angle

            arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha) 

    def hit(self):
        particles = [SmallAsteriods(self.center), SmallAsteriods(self.center)]
        
        particles[0].velocity.dx = self.velocity.dx + 1.5
        particles[0].velocity.dy = self.velocity.dy + 1.5

        particles[1].velocity.dx = self.velocity.dx + 1.5 * -1
        particles[1].velocity.dy = self.velocity.dy + 1.5 * -1

        return particles

class SmallAsteriods(Asteroids):
    def __init__(self,asteriod):
        super().__init__()
        self.rotation = SMALL_ROCK_SPIN
        self.radius = SMALL_ROCK_RADIUS
        self.center.x = asteriod.x
        self.center.y = asteriod.y

    def draw(self):
        try:    
            img = "D:/Program Files/d VS Code/asteriod/images/meteorGrey_small1.png"
            texture = arcade.load_texture(img)
        #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        except FileNotFoundError:    
            img = "images/meteorGrey_small1.png"
            texture = arcade.load_texture(img)
        finally:
            width = texture.width
            height = texture.height
            alpha = 255

            x = self.center.x
            y = self.center.y
            angle = self.angle

            arcade.draw_texture_rectangle(x, y, width, height, texture, angle, alpha) 
    
    def hit(self):
        particles = []
        return particles

class Game(arcade.Window):
    """
    This class handles all the game callbacks and interaction

    This class will then call the appropriate functions of
    each of the above classes.

    You are welcome to modify anything in this class.
    """

    def __init__(self, width, height):
        """
        Sets up the initial conditions of the game
        :param width: Screen width
        :param height: Screen height
        """
        super().__init__(width, height)
        arcade.set_background_color(arcade.color.SMOKY_BLACK)

        self.held_keys = set()

        # TODO: declare anything here you need the game class to track
        self.ship = Ship()
        self.score = 0
        self.bullets = []
        self.asteroids = []
        try:
            self.background = arcade.load_texture("D:/Program Files/d VS Code/asteriod/images/bgu.jpg")
        except FileNotFoundError:
            self.background = arcade.load_texture("images/bgu.jpg")
        #  I use the commented img (full path) in vscode as I am having issue with filepath, the program works fine in pycharm
        #create asteroids
        for i in range(5):
            asteroid = LargeAsteriods()
            self.asteroids.append(asteroid)        

        # my add on: Load sounds. Sounds from kenney.nl
        self.fire_sound = arcade.sound.load_sound(":resources:sounds/laser1.wav") 
        self.hit_sound = arcade.sound.load_sound(":resources:sounds/explosion1.wav")
        
        

    def on_draw(self):
        """
        Called automatically by the arcade framework.
        Handles the responsibility of drawing all elements.
        """

        # clear the screen to begin drawing
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, self.background)

        # TODO: draw each object
        

        for bullet in self.bullets:
            bullet.draw()        

        for asteroid in self.asteroids:
            asteroid.draw()

        #for debugging
        #self.draw_congratulations()  
       
        if self.ship.alive:
            
            self.ship.draw()
            self.draw_score()

        if len(self.asteroids) == 0:
            self.ship.alive = False
            self.draw_congratulations()       

    def update(self, delta_time):
        """
        Update each object in the game.
        :param delta_time: tells us how much time has actually elapsed
        """
        self.check_keys()
        self.check_collisions()

        # TODO: Tell everything to advance or move forward one step in time
        self.ship.advance()
        self.ship.is_off_screen(SCREEN_WIDTH, SCREEN_HEIGHT)

        for bullet in self.bullets:
            bullet.advance()
            bullet.is_off_screen(SCREEN_WIDTH,SCREEN_HEIGHT)   
            bullet.travel += 1     

        for asteroid in self.asteroids:
            asteroid.advance()
            asteroid.is_off_screen(SCREEN_WIDTH,SCREEN_HEIGHT)

        if self.ship.alive:   
            self.score += delta_time
        # TODO: Check for collisions
    def check_collisions(self):
        """
        Checks to see if bullets have hit asteroids.
        Updates scores and removes dead items.
        :return:
        """

        # NOTE: This assumes you named your asteroids list "asteroids"
        #on progress this should bounce the asteroid when it hit ship and other asteroid
        #ship and asteroid
        for asteroid in self.asteroids:

            # Make sure they are both alive before checking for a collision
          
            if self.ship.alive and asteroid.alive:
                    too_close = self.ship.radius + asteroid.radius

                    if (abs(self.ship.center.x - asteroid.center.x) < too_close and
                                abs(self.ship.center.y - asteroid.center.y) < too_close):        

                        
                        if asteroid.center.x > self.ship.center.x and asteroid.velocity.dx > self.ship.velocity.dx:
                            asteroid.bounce_horizontal()
                            self.ship.bounce_vertical()
                        
                        if asteroid.center.x < self.ship.center.x and asteroid.velocity.dx < self.ship.velocity.dx:
                            asteroid.bounce_horizontal()
                            self.ship.bounce_vertical()
                        
                        if asteroid.center.y > self.ship.center.y and asteroid.velocity.dy > self.ship.velocity.dy:
                            asteroid.bounce_vertical()
                            self.ship.bounce_horizontal()
                        
                        if asteroid.center.y < self.ship.center.y and asteroid.velocity.dy < self.ship.velocity.dy:
                            asteroid.bounce_vertical()
                            self.ship.bounce_horizontal()
        
        #asteroid to asteroid
        for asteroid1 in self.asteroids:
            for asteroid in self.asteroids:
            # Make sure they are both alive before checking for a collision
          
                if asteroid1.alive and asteroid.alive:
                        too_close = asteroid1.radius + asteroid.radius

                        if (abs(asteroid1.center.x - asteroid.center.x) < too_close and
                                    abs(asteroid1.center.y - asteroid.center.y) < too_close):        
                    
                            if asteroid.center.x > asteroid1.center.x and asteroid.velocity.dx > asteroid1.velocity.dx:
                                asteroid.bounce_horizontal()
                            
                            if asteroid.center.x < asteroid1.center.x and asteroid.velocity.dx < asteroid1.velocity.dx:
                                asteroid.bounce_horizontal()
                            
                            if asteroid.center.y > asteroid1.center.y and asteroid.velocity.dy > asteroid1.velocity.dy:
                                asteroid.bounce_horizontal()
                            
                            if asteroid.center.y < asteroid1.center.y and asteroid.velocity.dy < asteroid1.velocity.dy:
                                asteroid.bounce_horizontal()
    
                            
        #bullets and asteroid
        for bullet in self.bullets:
            for asteroid in self.asteroids:

                # Make sure they are both alive before checking for a collision
                if bullet.alive and asteroid.alive:
                    too_close = bullet.radius + asteroid.radius

                    if (abs(bullet.center.x - asteroid.center.x) < too_close and
                                abs(bullet.center.y - asteroid.center.y) < too_close):
                        # its a hit!
                        bullet.alive = False
                        asteroid.alive = False
                        self.asteroids = self.asteroids + asteroid.hit()
                        arcade.play_sound(self.hit_sound)

                        # We will wait to remove the dead objects until after we
                        # finish going through the list

        # Now, check for anything that is dead, and remove it
        self.cleanup_zombies()

    def cleanup_zombies(self):
        """
        Removes any dead bullets or asteroids from the list.
        :return:
        """
        for bullet in self.bullets:
            if bullet.travel == BULLET_LIFE:
                bullet.alive = False
            
            if not bullet.alive:
                self.bullets.remove(bullet)

        for asteroid in self.asteroids:
            if not asteroid.alive:
                self.asteroids.remove(asteroid)

    def check_keys(self):
        """
        This function checks for keys that are being held down.
        You will need to put your own method calls in here.
        """
        if arcade.key.LEFT in self.held_keys:
            self.ship.angle += SHIP_TURN_AMOUNT

        if arcade.key.RIGHT in self.held_keys:
            self.ship.angle -= SHIP_TURN_AMOUNT


        if arcade.key.UP in self.held_keys:
            self.ship.velocity.dx += math.cos(math.radians(self.ship.angle + 90)) * SHIP_THRUST_AMOUNT
            self.ship.velocity.dy += math.sin(math.radians(self.ship.angle + 90)) * SHIP_THRUST_AMOUNT

            if self.ship.velocity.dx > 3:
                self.ship.velocity.dx = 3
            
            if self.ship.velocity.dx < -3:
                self.ship.velocity.dx = -3
            
            if self.ship.velocity.dy > 3:
                self.ship.velocity.dy = 3
            
            if self.ship.velocity.dy < -3:
                self.ship.velocity.dy = -3

        
        if arcade.key.DOWN in self.held_keys:
            self.ship.velocity.dx -= math.cos(math.radians(self.ship.angle + 90)) * SHIP_THRUST_AMOUNT
            self.ship.velocity.dy -= math.sin(math.radians(self.ship.angle + 90)) * SHIP_THRUST_AMOUNT

            if self.ship.velocity.dx > 3:
                self.ship.velocity.dx = 3
            
            if self.ship.velocity.dx < -3:
                self.ship.velocity.dx = -3
            
            if self.ship.velocity.dy > 3:
                self.ship.velocity.dy = 3
            
            if self.ship.velocity.dy < -3:
                self.ship.velocity.dy = -3

        # Machine gun mode...
        #if arcade.key.SPACE in self.held_keys:
        #    pass


    def on_key_press(self, key: int, modifiers: int):
        """
        Puts the current key in the set of keys that are being held.
        You will need to add things here to handle firing the bullet.
        """
        if self.ship.alive:
            self.held_keys.add(key)

            if key == arcade.key.SPACE:
                # TODO: Fire the bullet here!
                # Fire!
                ship = self.ship

                #get the instance of bullet then align it with the ship's location and angle
                bullet = Bullet()
                bullet.fire(ship)
                #my addtional sound
                arcade.play_sound(self.fire_sound)
                self.bullets.append(bullet)

    def on_key_release(self, key: int, modifiers: int):
        """
        Removes the current key from the set of held keys.
        """
        if key in self.held_keys:
            self.held_keys.remove(key)
    
    def draw_congratulations(self):
        """
        Print the message "Congratulations" and show the score(time lapse) 
        """
        congrats = "Congratulations!"
        start_x = SCREEN_WIDTH // 2
        start_y = SCREEN_HEIGHT // 2
        arcade.draw_text(congrats, start_x=start_x, start_y=start_y, font_size= 20, color=arcade.color.WHITE, anchor_x="center")   

        lapse = f"Time Lapse: {self.score}"
        start_x = SCREEN_WIDTH // 2
        start_y = SCREEN_HEIGHT // 2 - 30
        arcade.draw_text(lapse, start_x=start_x, start_y=start_y, font_size= 20, color=arcade.color.WHITE, anchor_x="center")   

    def draw_score(self):
        """
        Puts the current score on the screen
        """
        score_text = f"Time Lapse: {self.score}"
        start_x = 10
        start_y = SCREEN_HEIGHT - 20
        arcade.draw_text(score_text, start_x=start_x, start_y=start_y, font_size=12, color=arcade.color.WHITE_SMOKE)


# Creates the game and starts it going
window = Game(SCREEN_WIDTH, SCREEN_HEIGHT)
arcade.run()